# zadání
- Vytvořte zrcadlený svazek 
	- kapacita pro data 250MB
	- NTFS
	- G:
- na disku vytvořte 1 složku a v ní 2 txt soubory, poté zrcadlo rozdělte na 2 jednoduché svazky a ověřte jejich obsah

## Diskpart
- list disk / list part
- select
- create
- delete
- detail
- clean
- format